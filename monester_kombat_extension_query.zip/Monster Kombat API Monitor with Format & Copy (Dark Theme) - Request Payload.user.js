// ==UserScript==
// @name         Monster Kombat API Monitor with Format & Copy (Dark Theme) - Request Payload
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  Menampilkan API request payload dari domain api.monsterkombat.io, serta menyediakan tombol untuk memformat dan menyalin payload sign-in ke clipboard. (Dark Theme)
// @match        https://game.monsterkombat.io/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Variabel untuk menyimpan payload sign-in terakhir (dari request)
    let lastSignInPayload = null;

    // Buat container mod menu dengan tema gelap
    const modMenu = document.createElement('div');
    modMenu.id = "apiMonitor";
    modMenu.style.position = "fixed";
    modMenu.style.top = "100px";
    modMenu.style.left = "100px";
    modMenu.style.width = "350px";
    modMenu.style.background = "#222";
    modMenu.style.border = "2px solid #555";
    modMenu.style.zIndex = "9999";
    modMenu.style.padding = "10px";
    modMenu.style.boxShadow = "2px 2px 10px rgba(0,0,0,0.7)";
    modMenu.style.color = "#fff";
    modMenu.style.fontFamily = "monospace";

    // Header (digunakan sebagai drag handle)
    const header = document.createElement('div');
    header.textContent = "API Monitor (Request Payload)";
    header.style.background = "#444";
    header.style.padding = "5px";
    header.style.cursor = "move";
    header.style.fontWeight = "bold";
    modMenu.appendChild(header);

    // Tombol Clear Logs
    const clearButton = document.createElement('button');
    clearButton.textContent = "Clear Logs";
    clearButton.style.margin = "10px 5px 10px 0";
    clearButton.style.padding = "5px 10px";
    clearButton.style.background = "#555";
    clearButton.style.color = "#fff";
    clearButton.style.border = "none";
    clearButton.style.cursor = "pointer";
    modMenu.appendChild(clearButton);

    // Tombol Format & Copy
    const formatCopyButton = document.createElement('button');
    formatCopyButton.textContent = "Format & Copy";
    formatCopyButton.style.margin = "10px 5px 10px 0";
    formatCopyButton.style.padding = "5px 10px";
    formatCopyButton.style.background = "#555";
    formatCopyButton.style.color = "#fff";
    formatCopyButton.style.border = "none";
    formatCopyButton.style.cursor = "pointer";
    modMenu.appendChild(formatCopyButton);

    // Container untuk menampilkan log API
    const logContainer = document.createElement('div');
    logContainer.style.height = "300px";
    logContainer.style.overflowY = "auto";
    logContainer.style.background = "#333";
    logContainer.style.padding = "5px";
    logContainer.style.border = "1px solid #555";
    modMenu.appendChild(logContainer);

    document.body.appendChild(modMenu);

    // Fungsi agar mod menu bisa digeser (draggable)
    header.addEventListener('mousedown', dragMouseDown);
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    function dragMouseDown(e) {
        e.preventDefault();
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.addEventListener('mouseup', closeDragElement);
        document.addEventListener('mousemove', elementDrag);
    }
    function elementDrag(e) {
        e.preventDefault();
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        modMenu.style.top = (modMenu.offsetTop - pos2) + "px";
        modMenu.style.left = (modMenu.offsetLeft - pos1) + "px";
    }
    function closeDragElement() {
        document.removeEventListener('mouseup', closeDragElement);
        document.removeEventListener('mousemove', elementDrag);
    }

    // Fungsi untuk menambahkan log ke dalam logContainer
    function logApiCall(type, url, payload) {
        const logEntry = document.createElement('div');
        const timeStr = new Date().toLocaleTimeString();
        let payloadStr = payload;
        if (typeof payload === 'object') {
            try {
                payloadStr = JSON.stringify(payload);
            } catch(e) {
                payloadStr = String(payload);
            }
        }
        logEntry.textContent = `[${timeStr}] [${type}] ${url}\nPayload: ${payloadStr}`;
        logEntry.style.borderBottom = "1px solid #555";
        logEntry.style.padding = "5px 0";
        logContainer.appendChild(logEntry);
        // Scroll ke bawah secara otomatis
        logContainer.scrollTop = logContainer.scrollHeight;
    }

    // Event tombol Clear Logs
    clearButton.addEventListener('click', function() {
        logContainer.innerHTML = "";
    });

    // Event tombol Format & Copy
    formatCopyButton.addEventListener('click', function() {
        if (!lastSignInPayload) {
            alert("Payload sign-in belum tercapture.");
            return;
        }
        let formatted = "";
        let parsedPayload = lastSignInPayload;
        // Jika payload berupa string, coba parse ke JSON
        if (typeof parsedPayload === 'string') {
            try {
                parsedPayload = JSON.parse(parsedPayload);
            } catch(e) {
                alert("Payload tidak valid.");
                return;
            }
        }
        // Jika payload memiliki properti message, signature, dan address
        if (parsedPayload.message && parsedPayload.signature && parsedPayload.address) {
            let timestamp = "";
            const match = parsedPayload.message.match(/Connect time:\s*(\d+)/);
            if (match) {
                timestamp = match[1];
            }
            formatted = `${parsedPayload.signature}|${parsedPayload.address}|${timestamp}`;
        } else if (parsedPayload.accessToken && parsedPayload.refreshToken) {
            // Jika payload memiliki accessToken dan refreshToken
            formatted = `${parsedPayload.accessToken}|${parsedPayload.refreshToken}`;
        } else {
            formatted = JSON.stringify(parsedPayload);
        }
        // Salin hasil format ke clipboard
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(formatted).then(() => {
                alert("Formatted payload telah disalin ke clipboard:\n" + formatted);
            }).catch(err => {
                alert("Gagal menyalin payload: " + err);
            });
        } else {
            const textarea = document.createElement("textarea");
            textarea.value = formatted;
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy');
                alert("Formatted payload telah disalin ke clipboard:\n" + formatted);
            } catch (err) {
                alert("Gagal menyalin payload: " + err);
            }
            document.body.removeChild(textarea);
        }
    });

    // Intercept fetch untuk menangkap request payload
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
        const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url);
        let requestPayload = null;
        if (args[1] && args[1].body) {
            requestPayload = args[1].body;
        }
        if(url && url.includes("https://api.monsterkombat.io")) {
            logApiCall("fetch (Request)", url, requestPayload);
            if(url.includes("/auth/sign-in")) {
                lastSignInPayload = requestPayload;
            }
        }
        return originalFetch.apply(this, args);
    };

    // Intercept XMLHttpRequest untuk menangkap request payload
    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
        this._url = url;
        this._method = method;
        return origOpen.apply(this, arguments);
    };

    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(body) {
        if (this._url && this._url.includes("https://api.monsterkombat.io")) {
            logApiCall("XHR (Request)", this._url, body);
            if(this._url.includes("/auth/sign-in")) {
                lastSignInPayload = body;
            }
        }
        return origSend.apply(this, arguments);
    };

})();
